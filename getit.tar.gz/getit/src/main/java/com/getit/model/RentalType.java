package com.getit.model;

public enum RentalType {
	HOURLY,
	DAILY
}