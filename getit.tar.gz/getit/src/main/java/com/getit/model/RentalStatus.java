package com.getit.model;

public enum RentalStatus {
	PENDING,
	APPROVED,
	ACTIVE,
	COMPLETED,
	CANCELLED
}